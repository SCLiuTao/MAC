//
//  AppDelegate.h
//  WKWebViewDemo
//
//  Created by 姜雨生 on 16/4/30.
//  Copyright © 2016年 姜雨生. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

